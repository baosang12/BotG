﻿# Postrun Report
- Timestamp: 
- Acceptance (smoke): UNKNOWN

## Changes
# Copilot changes

- ecff7313d4e569fdc053834371cfe9d111b40b3c | BotG Dev <botg@example.com> | Wed Aug 27 15:18:23 2025 +0700 | chore(postrun): add PR body + checklist and packaged artifacts for review
  files: path_issues/postrun_checklist.md, path_issues/postrun_pr_body.md
  diff: path_issues/copilot_changes__ecff7313d4e569fdc053834371cfe9d111b40b3c.diff
- 96f5a5a6b75de78a4773d50a19514d4ca723654d | BotG Dev <botg@example.com> | Wed Aug 27 14:17:47 2025 +0700 | tools: ReconstructClosedTrades header-aware parsing + robust fill detection; postrun artifacts updated (20250827_141746)
  files: Tools/ReconstructClosedTrades/Program.cs, path_issues/agent_ts.txt, path_issues/latest_zip.txt, path_issues/postrun_artifacts_20250827_141746.sha256, path_issues/postrun_artifacts_20250827_141746.zip
  diff: path_issues/copilot_changes__96f5a5a6b75de78a4773d50a19514d4ca723654d.diff
- 39588d174a55dfc2b4ae4d1405ee882ebad5f3b9 | BotG Dev <botg@example.com> | Wed Aug 27 14:12:16 2025 +0700 | postrun: reconstruct+analyze with richer orders.csv; update artifacts+zip (20250827_141215)
  files: path_issues/agent_summary_20250827_124502.json, path_issues/agent_ts.txt, path_issues/build_and_test_output.txt, path_issues/fillrate_by_hour.png, path_issues/git_commit2.txt, path_issues/git_push2.txt, path_issues/latency_percentiles.png, path_issues/latest_zip.txt, path_issues/orders_ascii.csv, path_issues/postrun_artifacts_20250827_124502.sha256, path_issues/postrun_artifacts_20250827_124502.zip, path_issues/postrun_artifacts_20250827_141215.sha256, path_issues/postrun_artifacts_20250827_141215.zip, path_issues/pr_open_url.txt, path_issues/slippage_hist.png
  diff: path_issues/copilot_changes__39588d174a55dfc2b4ae4d1405ee882ebad5f3b9.diff
- 954006249d0547943c41819b559281416a4a4c74 | BotG Dev <botg@example.com> | Wed Aug 27 14:03:05 2025 +0700 | chore(postrun): make analysis resilient to simple orders.csv; add fallback artifacts
  files: path_issues/agent_summary_20250827_124502.json, path_issues/closed_trades_fifo_reconstructed.csv, path_issues/git_add.txt, path_issues/git_commit.txt, path_issues/git_push.txt, path_issues/git_status.txt, path_issues/reconstruct_report.json
  diff: path_issues/copilot_changes__954006249d0547943c41819b559281416a4a4c74.diff
- bc03f2dc370cfece86f7999d0060867118f75d24 | BotG Dev <botg@example.com> | Wed Aug 27 13:50:15 2025 +0700 | fix(postrun): reconcile PnL, slippage/latency analysis + plots, runbook & CI; minor logging patch (if applied)
  files: Harness/Program.cs, docs/runbook_postrun.md, path_issues/README.txt, path_issues/agent_summary_20250827_124841.json, path_issues/agent_ts.txt, path_issues/build_and_test_output.txt, path_issues/draintag_fix_report.txt, path_issues/fillrate_hourly.csv, path_issues/findings_paths_to_fix.txt, path_issues/git_checkout.txt, path_issues/git_revparse.txt, path_issues/git_try.txt, path_issues/latest_zip.txt, path_issues/orders_ascii.csv, path_issues/postrun_artifacts_20250827_124017.zip, path_issues/postrun_artifacts_20250827_124502.sha256, path_issues/postrun_artifacts_20250827_124502.zip, path_issues/postrun_artifacts_20250827_124841.zip, path_issues/postrun_summary.txt, path_issues/reconstruct_report.json, path_issues/slip_latency_percentiles.json, path_issues/top_slippage.csv, scripts/analyze_postrun.py, scripts/postrun_analyze.ps1
  diff: path_issues/copilot_changes__bc03f2dc370cfece86f7999d0060867118f75d24.diff
- 04e81146f97dca63fc916cf43e4de1b24e28dd2b | baosang12 <baosang.qh@gmail.com> | Thu Aug 21 18:42:18 2025 +0700 | Merge pull request #2 from baosang12/botg/automation/reconcile-streaming-20250821_084334
  files: 
  diff: path_issues/copilot_changes__04e81146f97dca63fc916cf43e4de1b24e28dd2b.diff
- c43c5fb3ce63f70847135d836841c1c9801f50a1 | baosang12 <baosang.qh@gmail.com> | Thu Aug 21 16:07:42 2025 +0700 | Merge pull request #1 from baosang12/copilot/fix-1b1b6f67-0825-4994-a041-0728d53e7ff9
  files: 
  diff: path_issues/copilot_changes__c43c5fb3ce63f70847135d836841c1c9801f50a1.diff

## Artifacts

## Telemetry analysis

## Action items
