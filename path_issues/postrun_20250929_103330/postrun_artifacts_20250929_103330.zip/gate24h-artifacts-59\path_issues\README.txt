This folder stores path scanning findings, build/test logs, and smoke verification outputs for the Unicode→ASCII path migration.

Files produced by scripts:
- findings_paths_to_fix.txt
- build_and_test_output.txt
- smoke_analysis_summary.json
- diagnostic_preview_head.csv
- closed_trades_head.csv
- orders_warnings_tail.txt
- summary_report.md
