REVIEW CHECKLIST
- [ ] Build: PASS (no errors)
- [ ] closed_trades_fifo_reconstructed.csv exists
- [ ] reconstruct_report.json: unmatched_orders_count <= 1% or documented
- [ ] slip_latency_percentiles.json + slippage_hist.png + latency_percentiles.png exist
- [ ] runbook_postrun.md present
- [ ] postrun_artifacts_20250827_143911.zip attached to PR
REVIEW CHECKLIST
- [ ] Build: PASS (no errors)
- [ ] closed_trades_fifo_reconstructed.csv exists
- [ ] reconstruct_report.json: unmatched_orders_count <= 1% or documented
- [ ] slip_latency_percentiles.json + slippage_hist.png + latency_percentiles.png exist
- [ ] runbook_postrun.md present
- [ ] postrun_artifacts_<ts>.zip attached to PR
