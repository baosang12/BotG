﻿# Weekend Full Readiness  20250830_104346
\n## Gates
| Gate | Status |
|------|--------|
| Build | PASS |
| Smoke | PASS |
| Reconstruct | PASS |
| Fill rate | N/A |
| Logging | PASS |
\n## Artifacts (checksummed)
| Name | File | Size | mtime (UTC) | SHA256 |
|------|------|------|-------------|--------|
| build.log | build.log | 1578 | 2025-08-30T03:44:01.8971744Z | 059F2BEB66661C25258F44B31C0510136FDA3A66632B149A420D7157274D173C |
| closed_trades_fifo.csv | closed_trades_fifo.csv | 41426 | 2025-08-30T03:46:02.3003027Z | 9281307F30F63A7B00867B2D67466244B2E93A474A8CB2F364AD0B4C669A0D7A |
| fillrate_by_hour.png | fillrate_by_hour.png | 5316 | 2025-08-27T07:04:24.3343173Z | A38B26D2E99EE641B7A1D8F2F2DFD89519BDEE0F038BE6DEE9F71F7026C39A57 |
| fillrate_hourly.csv | fillrate_hourly.csv | 103 | 2025-08-27T06:48:40.6523286Z | 0BA2358871E1B28D95FE4435EC82ACE8BA42C79B762B20C6ED89943D99FDCA11 |
| latency_percentiles.png | latency_percentiles.png | 5360 | 2025-08-27T07:04:24.3300403Z | B9BBD55294881EF9D522397ADB9E6AF829B016D575B0F39D77B06C09042CD4DA |
| orders.csv | orders.csv | 239794 | 2025-08-30T03:46:02.3003027Z | 95BA8BE8DAAD2CA907640C4BE2A0D2E8BAD0A26D95D981FF1EA67864659FEF6C |
| orders_ascii.csv | orders_ascii.csv | 10927 | 2025-08-25T06:19:11.8005244Z | D68FEA28C52BD0DBE25A048959EE58C8EFE2818EEE1F6FCAB3E48C6EBD9D9EC1 |
| risk_snapshots.csv | risk_snapshots.csv | 70 | 2025-08-30T03:44:05.0006111Z | C391F20B97B73D30B6E3D88DBBFAF0872C78CE500CD4AFE7AE29C6D76B317C90 |
| slippage_hist.png | slippage_hist.png | 5176 | 2025-08-27T07:04:24.3097841Z | 649ECC508286137060C2260915394948CFB7B7CBC2E543CE25AB1D8ABAC8629F |
| summary.json | summary.json | 1323 | 2025-08-30T03:46:03.2736532Z | E36C96E0F492A843CDDD1E2F4B78FC45A6E0921A21B6FCCA3E77469B8BE12359 |
| telemetry.csv | telemetry.csv | 3127 | 2025-08-30T03:46:01.0240846Z | 008FC3528A047FF2025669447C90D331D7E04939F55D09CAF6BC4D14C592B65C |
| telemetry_run_20250827_200336.zip | telemetry_run_20250827_200336.zip | 48901 | 2025-08-27T13:05:39.9629432Z | 3F88D20B0AF48EC6A2FBBFC4C13F5D8FE238E608868E538476BEB52BF29DA6D1 |
| telemetry_run_20250830_104358.zip | telemetry_run_20250830_104358.zip | 44946 | 2025-08-30T03:46:03.1685311Z | 452289A0B68691A25B6B175E3D86ADBBD79F1EEE4B4268EE72ADF49F8D69A40F |
| top_slippage.csv | top_slippage.csv | 116 | 2025-08-27T06:48:40.6523286Z | D02A1184FB37B6301F3BC7EC76F1F307770E47B624C7CFD2832E2A8DB2C79550 |
| trade_closes.log | trade_closes.log | 20966 | 2025-08-30T03:46:02.3003027Z | 27D0E4D404B73DC3DB99D19E1D7778AB4ABB2186BF831D60EC823F7511F026B9 |
\n## Copilot Readiness Statement
Based on the exhaustive checks run at 20250830_104346, all acceptance gates passed. To the maximum testable extent in this environment (short smoke + reconstruct + analyzer + build/tests), the system is READY for a 24h supervised paper run.
\n## Caveats (not a 100% mathematical guarantee)
- External broker/live environment not tested
- Production-scale latency not measured
- Market halts/outages not simulated
- Extreme-volatility slippage untested
\n## Next action
Run 24h supervised on Monday at operator-chosen time.
\n## One-line
KẾT THÚC: weekend short-smoke: PASS | readiness: READY | README: path_issues/postmerge_readme_20250830_101536.md
