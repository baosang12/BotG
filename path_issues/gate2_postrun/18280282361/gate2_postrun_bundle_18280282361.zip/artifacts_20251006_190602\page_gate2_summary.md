﻿# Gate2 Summary
\n## What
- Telemetry span: 0h
- Required files: 5/6 present
- KPIs: fills=350238, fill_rate=33.33%
\n## So-what
- Run duration too short
- Some files are missing
- Schema issues detected
\n## Next
- Investigate any listed reasons
- Re-run with paper mode and full 24h if needed
- Archive artifacts
